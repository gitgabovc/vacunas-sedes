<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_caja extends CI_Model {
	public function select_all() {
		$data = $this->db->get('caja');
		return $data->result();
	}

	public function select_by_id($id) {
		$sql = "SELECT * FROM caja WHERE id = '{$id}'";
		$data = $this->db->query($sql);
		return $data->row();
	}

	public function select_by_detalle($id) {
		$sql = " SELECT caja.id, caja.fecha, caja,glosa, detalle.cuenta, detalle.debe, detalle.haber 
		FROM caja, detalle WHERE caja.id = detalle.idcaja AND caja.id={$id}";
		$data = $this->db->query($sql);
		return $data->result();
	}

	public function insert($data) {
		// cabecera
		$sql = "INSERT INTO caja (fecha, detalle) VALUES('" .$data['fecha'] ."', '" .$data['detalle'] ."')";
		$this->db->query($sql);
		$idcaja = $this->db->insert_id();
		$nc = $this->db->affected_rows();
		// detalle
		$cuentas = $data['cuenta'];
		$conceptos = $data['concepto'];
		$importes = $data['importe'];
		$total = 0.0;
		foreach($cuentas as $row => $cta){
			$total += (float)$importes[$row];
			$debe = 0.0;  $haber = 0.0;
			if($data['tipo']=='I') $debe = (float)$importes[$row];
			else $haber = (float)$importes[$row];
			$sql = "INSERT INTO cajadet (idcaja, cuenta, concepto, debe, haber) VALUES('$idcaja','$cta','" .$conceptos[$row] ."','" .$debe."','" .$haber."')";
			$this->db->query($sql);
			$nc = $this->db->affected_rows();
		}
		$sql = "UPDATE caja SET total = " .$total ." WHERE id = $idcaja";
		$this->db->query($sql);
		return $nc;
	}

	public function insert_batch($data) {
		$this->db->insert_batch('caja', $data);
		
		return $this->db->affected_rows();
	}

	public function update($data) {
		$sql = "UPDATE caja SET fecha='" .$data['fecha'] ."' WHERE id='" .$data['id'] ."'";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function delete($id) {
		$sql = "DELETE FROM caja WHERE id='" .$id ."'";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function check_nama($nama) {
		$this->db->where('fecha', $nama);
		$data = $this->db->get('caja');
		return $data->num_rows();
	}

	public function total_rows() {
		$data = $this->db->get('caja');
		return $data->num_rows();
	}
}

/* End of file M_caja.php */
/* Location: ./application/models/M_caja.php */