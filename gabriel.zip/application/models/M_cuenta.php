<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_cuenta extends CI_Model {
	public function select_all_cuenta() {
		$sql = "SELECT * FROM cuenta";
		$data = $this->db->query($sql);
		return $data->result();
	}

	public function select_all() {
		$sql = " SELECT * FROM cuenta ";
		$data = $this->db->query($sql);
		return $data->result();
	}

	public function select_by_id($id) {
		$sql = "SELECT * 
		FROM cuenta 
		WHERE  cuenta.id = '{$id}'";
		$data = $this->db->query($sql);
		return $data->row();
	}

	public function update($data) {
		$sql = "UPDATE cuenta SET cuenta='" .$data['cuenta'] 
		."', descripcion='" .$data['descripcion']
		."' WHERE id='" .$data['id'] ."'";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function delete($id) {
		$sql = "DELETE FROM cuenta WHERE id='" .$id ."'";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function insert($data) {
		//$id = md5(DATE('ymdhms').rand());
		$sql = "INSERT INTO cuenta (cuenta, descripcion)
		VALUES('" .$data['cuenta']."','" .$data['descripcion'] ."')";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function insert_batch($data) {
		$this->db->insert_batch('cuenta', $data);		
		return $this->db->affected_rows();
	}

	public function check_nama($nama) {
		$this->db->where('cuenta', $nama);
		$data = $this->db->get('cuenta');
		return $data->num_rows();
	}

	public function total_rows() {
		$data = $this->db->get('cuenta');
		return $data->num_rows();
	}
}

/* End of file M_cuenta.php */
/* Location: ./application/models/M_cuenta.php */