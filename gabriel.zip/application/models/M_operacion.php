<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_operacion extends CI_Model {
	public function select_all_operacion() {
		$sql = "SELECT * FROM operacion";
		$data = $this->db->query($sql);
		return $data->result();
	}

	public function select_all() {
		$sql = " SELECT * FROM operacion ";
		$data = $this->db->query($sql);
		return $data->result();
	}

	public function select_by_id($id) {
		$sql = "SELECT * 
		FROM operacion 
		WHERE  operacion.id = '{$id}'";
		$data = $this->db->query($sql);
		return $data->row();
	}

	public function update($data) {
		$sql = "UPDATE operacion SET nombres='" .$data['nombres'] 
		."', apellidos='" .$data['apellidos']
		."', telefono='" .$data['telefono']
		."', direccion='" .$data['direccion']
		."', codigo='" .$data['codigo']
		."', ci='" .$data['ci']
		."', fecnac='" .$data['fecnac']
		."', fechain='" .$data['fechain']
		."', correo='" .$data['correo']
		."' WHERE id='" .$data['id'] ."'";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function delete($id) {
		$sql = "DELETE FROM operacion WHERE id='" .$id ."'";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function insert($data) {
		//$id = md5(DATE('ymdhms').rand());
		$sql = "INSERT INTO operacion (nombres, apellidos, telefono, direccion, codigo, ci, fecnac, fechain, correo)
		VALUES('" .$data['nombres']."','" .$data['apellidos'] ."','" .$data['telefono'].
		"','" .$data['direccion'] ."','" .$data['codigo'] ."','" .$data['ci'] ."','" .$data['fecnac'] .
		"','" .$data['fechain'] ."','" .$data['correo'] ."')";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function insert_batch($data) {
		$this->db->insert_batch('operacion', $data);		
		return $this->db->affected_rows();
	}

	public function check_nama($nama) {
		$this->db->where('nombres', $nama);
		$data = $this->db->get('operacion');
		return $data->num_rows();
	}

	public function total_rows() {
		$data = $this->db->get('operacion');
		return $data->num_rows();
	}
}

/* End of file M_operacion.php */
/* Location: ./application/models/M_operacion.php */