<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_agente extends CI_Model {
	public function select_all_agente() {
		$sql = "SELECT * FROM agente";
		$data = $this->db->query($sql);
		return $data->result();
	}

	public function select_all() {
		$sql = " SELECT * FROM agente ";
		$data = $this->db->query($sql);
		return $data->result();
	}

	public function select_by_id($id) {
		$sql = "SELECT * 
		FROM agente 
		WHERE  agente.id = '{$id}'";
		$data = $this->db->query($sql);
		return $data->row();
	}

	public function update($data) {
		$sql = "UPDATE agente SET nombres='" .$data['nombres'] 
		."', apellidos='" .$data['apellidos']
		."', telefono='" .$data['telefono']
		."', direccion='" .$data['direccion']
		."', codigo='" .$data['codigo']
		."', ci='" .$data['ci']
		."', fecnac='" .$data['fecnac']
		."', fechain='" .$data['fechain']
		."', correo='" .$data['correo']
		."' WHERE id='" .$data['id'] ."'";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function delete($id) {
		$sql = "DELETE FROM agente WHERE id='" .$id ."'";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function insert($data) {
		//$id = md5(DATE('ymdhms').rand());
		$sql = "INSERT INTO agente (nombres, apellidos, telefono, direccion, codigo, ci, fecnac, fechain, correo)
		VALUES('" .$data['nombres']."','" .$data['apellidos'] ."','" .$data['telefono'].
		"','" .$data['direccion'] ."','" .$data['codigo'] ."','" .$data['ci'] ."','" .$data['fecnac'] .
		"','" .$data['fechain'] ."','" .$data['correo'] ."')";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function insert_batch($data) {
		$this->db->insert_batch('agente', $data);		
		return $this->db->affected_rows();
	}

	public function check_nama($nama) {
		$this->db->where('nombres', $nama);
		$data = $this->db->get('agente');
		return $data->num_rows();
	}

	public function total_rows() {
		$data = $this->db->get('agente');
		return $data->num_rows();
	}
}

/* End of file M_agente.php */
/* Location: ./application/models/M_agente.php */