<div class="col-md-offset-1 col-md-10 col-md-offset-1 well">
  <div class="form-msg"></div>
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <h3 style="display:block; text-align:center;">Movimiento de Caja</h3>

  <?php echo form_open_multipart('caja/procesaInsert'); ?>

  <form id="form-caja" method="POST">
    <div class="input-group form-group">
      <span class="input-group-addon" id="sizing-addon1">
        <i class="glyphicon glyphicon-calendar"></i>
      </span>
      <input type="date" class="form-control" placeholder="Fecha" name="fecha" aria-describedby="sizing-addon1">
      <span class="input-group-addon" id="sizing-addon2">
      <i class="glyphicon glyphicon-tag"></i>
      </span>
      <span class="input-group-addon">
          <input type="radio" name="tipo" value="I" id="ingreso" class="minimal">
      <label for="ingreso">Ingreso</label>
        </span>
        <span class="input-group-addon">
          <input type="radio" name="tipo" value="E" id="egreso" class="minimal"> 
      <label for="egreso">Egreso</label>
        </span>
    </div>	
	
    <div class="input-group form-group">
      <span class="input-group-addon" id="sizing-addon3">
        <i class="glyphicon glyphicon-phone-alt"></i>
      </span>
      <input type="text" class="form-control" placeholder="Glosa" name="detalle" aria-describedby="sizing-addon3">
    </div>	
	

    <div class="input-group form-group" >
            <div class="col-md-3">
				  <select name="cuenta[]" class="form-control " >
					<?php foreach ($dataCuenta as $cta) { ?>
					  <option value="<?php echo $cta->cuenta; ?>">
						<?php echo $cta->cuenta.' - '.$cta->descripcion; ?>
					  </option>
					  <?php } ?>
				  </select>
            </div>
            <div class="col-md-6">
                    <input type="text" name="concepto[]" class="form-control" placeholder="Detalle">
            </div>
            <div class="col-md-3">
                    <input type="text" name="importe[]" class="form-control" placeholder="Importe">
            </div>
    </div>
    <div class="input-group form-group" >
            <div class="col-md-3">
				  <select name="cuenta[]" class="form-control " >
					<?php foreach ($dataCuenta as $cta) { ?>
					  <option value="<?php echo $cta->cuenta; ?>">
						<?php echo $cta->cuenta.' - '.$cta->descripcion; ?>
					  </option>
					  <?php } ?>
				  </select>
            </div>
            <div class="col-md-6">
                    <input type="text" name="concepto[]" class="form-control" placeholder="Detalle">
            </div>
            <div class="col-md-3">
                    <input type="text" name="importe[]" class="form-control" placeholder="Importe">
            </div>
    </div>
    <div class="input-group form-group" >
            <div class="col-md-3">
				  <select name="cuenta[]" class="form-control ">
					<?php foreach ($dataCuenta as $cta) { ?>
					  <option value="<?php echo $cta->cuenta; ?>">
						<?php echo $cta->cuenta.' - '.$cta->descripcion; ?>
					  </option>
					  <?php } ?>
				  </select>
            </div>
            <div class="col-md-6">
                    <input type="text" name="concepto[]" class="form-control" placeholder="Detalle">
            </div>
            <div class="col-md-3">
                    <input type="text" name="importe[]" class="form-control" placeholder="Importe">
            </div>
    </div>
    <div class="input-group form-group" >
            <div class="col-md-3">
				  <select name="cuenta[]" class="form-control ">
					<?php foreach ($dataCuenta as $cta) { ?>
					  <option value="<?php echo $cta->cuenta; ?>">
						<?php echo $cta->cuenta.' - '.$cta->descripcion; ?>
					  </option>
					  <?php } ?>
				  </select>
            </div>
            <div class="col-md-6">
                    <input type="text" name="concepto[]" class="form-control" placeholder="Detalle">
            </div>
            <div class="col-md-3">
                    <input type="text" name="importe[]" class="form-control" placeholder="Importe">
            </div>
    </div>
    <div class="input-group form-group" >
            <div class="col-md-3">
				  <select name="cuenta[]" class="form-control ">
					<?php foreach ($dataCuenta as $cta) { ?>
					  <option value="<?php echo $cta->cuenta; ?>">
						<?php echo $cta->cuenta.' - '.$cta->descripcion; ?>
					  </option>
					  <?php } ?>
				  </select>
            </div>
            <div class="col-md-6">
                    <input type="text" name="concepto[]" class="form-control" placeholder="Detalle">
            </div>
            <div class="col-md-3">
                    <input type="text" name="importe[]" class="form-control" placeholder="Importe">
            </div>
    </div>
	
	
				
    <div class="form-group">
      <div class="col-md-12">
          <button type="submit" class="form-control btn btn-primary"> <i class="glyphicon glyphicon-ok"></i> Guardar</button>
      </div>
    </div>
  </form>

  <?php echo form_close(); ?>

</div>