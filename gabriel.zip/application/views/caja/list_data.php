<?php
  $no = 1;
  foreach ($dataCaja as $caja) {
    ?>
    <tr>
      <td><?php echo $no; ?></td>
      <td><?php echo $caja->fecha; ?></td>
      <td><?php echo $caja->detalle; ?></td>
      <td class="text-center" style="min-width:230px;">
        <button class="btn btn-warning update-dataCaja" data-id="<?php echo $caja->id; ?>"><i class="glyphicon glyphicon-repeat"></i> Mod</button>
        <button class="btn btn-danger konfirmasiHapus-caja" data-id="<?php echo $caja->id; ?>" data-toggle="modal" data-target="#konfirmasiHapus"><i class="glyphicon glyphicon-remove-sign"></i> Eli</button>
        <button class="btn btn-info detail-dataCaja" data-id="<?php echo $caja->id; ?>"><i class="glyphicon glyphicon-info-sign"></i> Detalle</button>
      </td>
    </tr>
    <?php
    $no++;
  }
?>