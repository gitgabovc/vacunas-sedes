<div class="col-md-12 well">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <h3 style="display:block; text-align:center;"><i class="fa fa-briefcase"></i> Detalle (Caja: <b><?php echo $caja->descripcion; ?></b>)</h3>

  <div class="box box-body">
      <table id="tabel-detail" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Cuenta</th>
            <th>Descripcion</th>
            <th>Debe</th>
            <th>Haber</th>
          </tr>
        </thead>
        <tbody id="data-pegawai">
          <?php
            foreach ($dataCaja as $item) {
              ?>
              <tr>
                <td style="min-width:230px;"><?php echo $item->cuenta; ?></td>
                <td><?php echo $item->descripcion; ?></td>
                <td><?php echo $item->debe; ?></td>
                <td><?php echo $item->haber; ?></td>
              </tr>
              <?php
            }
          ?>
        </tbody>
      </table>
  </div>

  <div class="text-right">
    <button class="btn btn-danger" data-dismiss="modal"> Cerrar</button>
  </div>
</div>