<?php
  foreach ($datacuenta as $item) {
    ?>
    <tr>
      <td style="min-width:230px;"><?php echo $item->cuenta; ?></td>
      <td><?php echo $item->descripcion; ?></td>
      <td class="text-center" style="min-width:230px;">
        <button class="btn btn-warning update-cuenta" data-id="<?php echo $item->id; ?>"><i class="glyphicon glyphicon-repeat"></i> Mod</button>
        <button class="btn btn-danger confirmarDel-cuenta" data-id="<?php echo $item->id; ?>" data-toggle="modal" data-target="#confirmarDel"><i class="glyphicon glyphicon-remove-sign"></i> Eli</button>
      </td>
    </tr>
    <?php
  }
?>