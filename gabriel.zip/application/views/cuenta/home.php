<div class="msg" style="display:none;">
  <?php echo @$this->session->flashdata('msg'); ?>
</div>

<div class="box">
  <div class="box-header">
    <div class="col-md-6" style="padding: 0;">
        <button class="form-control btn btn-primary" data-toggle="modal" data-target="#modal-cuenta"><i class="glyphicon glyphicon-plus-sign"></i> Adicionar</button>
    </div>
    <div class="col-md-3">
        <a href="<?php echo site_url('Cuenta/export'); ?>" class="form-control btn btn-default"><i class="glyphicon glyphicon glyphicon-floppy-save"></i> Export Data Excel</a>
    </div>
    <div class="col-md-3">
        <button class="form-control btn btn-default" data-toggle="modal" data-target="#import-cuenta"><i class="glyphicon glyphicon glyphicon-floppy-open"></i> Import Data Excel</button>
    </div>
  </div>
  <!-- /.box-header -->
  <div class="box-body">
    <table id="list-data" class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>Cuenta</th>
          <th>Descripción</th>
          <th style="text-align: center;">Operaciones</th>
        </tr>
      </thead>
      <tbody id="data-cuenta">
        
      </tbody>
    </table>
  </div>
</div>

<?php echo $modal_cuenta; ?>

<div id="tempat-modal"></div>

<?php show_my_confirm('confirmarDel', 'boxDelete', 'Seguro de eliminar?', 'Si, eliminar'); ?>
<?php
  $data['modalTitle'] = 'Cuenta';
  $data['url'] = 'cuenta/import';
  echo show_my_modal('modals/modal_import', 'import-cuenta', $data);
?>