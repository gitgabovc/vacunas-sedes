<footer class="main-footer">
	<!-- To the right -->
	<div class="pull-right hidden-xs">
		Dashboard Admin
	</div>
	<!-- Default to the left -->
	<strong>Copyright &copy; 2022 <a href="#">SEDES CBBA</a>.</strong> Derechos reservados.
</footer>