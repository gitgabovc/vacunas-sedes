<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_usuario extends CI_Model {
	public function select_all_usuario() {
		$sql = "SELECT * FROM usuario";
		$data = $this->db->query($sql);
		return $data->result();
	}

	public function select_all() {
		$sql = " SELECT usuario.id AS id, usuario.nama AS usuario, usuario.telp AS telp, 
		kota.nama AS kota, kelamin.nama AS kelamin, posisi.nama AS posisi 
		FROM usuario, kota, kelamin, posisi 
		WHERE usuario.id_kelamin = kelamin.id AND usuario.id_posisi = posisi.id AND usuario.id_kota = kota.id";
		$data = $this->db->query($sql);
		return $data->result();
	}

	public function select_by_id($id) {
		$sql = "SELECT usuario.id AS id_usuario, usuario.nama AS nama_usuario, usuario.id_kota, usuario.id_kelamin, usuario.id_posisi, usuario.telp AS telp, 
		kota.nama AS kota, kelamin.nama AS kelamin, posisi.nama AS posisi 
		FROM usuario, kota, kelamin, posisi 
		WHERE usuario.id_kota = kota.id AND usuario.id_kelamin = kelamin.id AND usuario.id_posisi = posisi.id AND usuario.id = '{$id}'";
		$data = $this->db->query($sql);
		return $data->row();
	}

	public function select_by_posisi($id) {
		$sql = "SELECT COUNT(*) AS jml FROM usuario WHERE id_posisi = {$id}";
		$data = $this->db->query($sql);
		return $data->row();
	}

	public function select_by_kota($id) {
		$sql = "SELECT COUNT(*) AS jml FROM usuario WHERE id_kota = {$id}";
		$data = $this->db->query($sql);
		return $data->row();
	}

	public function update($data) {
		$sql = "UPDATE usuario SET nama='" .$data['nama'] 
		."', telp='" .$data['telp'] ."', id_kota=" .$data['kota'] .", id_kelamin=" 
		.$data['jk'] .", id_posisi=" .$data['posisi'] 
		." WHERE id='" .$data['id'] ."'";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function delete($id) {
		$sql = "DELETE FROM usuario WHERE id='" .$id ."'";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function insert($data) {
		$id = md5(DATE('ymdhms').rand());
		$sql = "INSERT INTO usuario VALUES('{$id}','" .$data['nama'] 
		."','" .$data['telp'] ."'," .$data['kota'] ."," .$data['jk'] ."," .$data['posisi'] .",1)";
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	public function insert_batch($data) {
		$this->db->insert_batch('usuario', $data);		
		return $this->db->affected_rows();
	}

	public function check_nama($nama) {
		$this->db->where('nama', $nama);
		$data = $this->db->get('usuario');
		return $data->num_rows();
	}

	public function total_rows() {
		$data = $this->db->get('usuario');
		return $data->num_rows();
	}
}

/* End of file M_usuario.php */
/* Location: ./application/models/M_usuario.php */