<?php
  $no = 1;
  foreach ($dataTipoinmueble as $tipoinmueble) {
    ?>
    <tr>
      <td><?php echo $no; ?></td>
      <td><?php echo $tipoinmueble->descripcion; ?></td>
      <td class="text-center" style="min-width:230px;">
          <button class="btn btn-warning update-dataTipoinmueble" data-id="<?php echo $tipoinmueble->id; ?>"><i class="glyphicon glyphicon-repeat"></i> Mod</button>
          <button class="btn btn-danger konfirmasiHapus-tipoinmueble" data-id="<?php echo $tipoinmueble->id; ?>" data-toggle="modal" data-target="#konfirmasiHapus"><i class="glyphicon glyphicon-remove-sign"></i> Eli</button>
      </td>
    </tr>
    <?php
    $no++;
  }
?>