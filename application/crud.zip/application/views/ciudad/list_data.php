<?php
  $no = 1;
  foreach ($dataCiudad as $ciudad) {
    ?>
    <tr>
      <td><?php echo $no; ?></td>
      <td><?php echo $ciudad->descripcion; ?></td>
      <td class="text-center" style="min-width:230px;">
          <button class="btn btn-warning update-dataCiudad" data-id="<?php echo $ciudad->id; ?>"><i class="glyphicon glyphicon-repeat"></i> Mod</button>
          <button class="btn btn-danger konfirmasiHapus-ciudad" data-id="<?php echo $ciudad->id; ?>" data-toggle="modal" data-target="#konfirmasiHapus"><i class="glyphicon glyphicon-remove-sign"></i> Eli</button>
      </td>
    </tr>
    <?php
    $no++;
  }
?>